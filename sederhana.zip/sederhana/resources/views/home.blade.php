@extends('tem')

@section('konten')
<br><hr>
    <h4>
        Selamat Datang 
        <b>{{ Auth::user()->name }}</b>, 
        Anda Login sebagai 
        <b>{{ Auth::user()->email }}</b>
    </h4>
@endsection