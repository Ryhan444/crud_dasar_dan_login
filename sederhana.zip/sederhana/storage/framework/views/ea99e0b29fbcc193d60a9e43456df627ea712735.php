<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title> Login Laravel</title>

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    </head>

    <body>
        <div class="container">
          
                <nav class="navbar navbar-expand-lg navbar-light bg-success">
                    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">HOME</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                      <ul class="navbar-nav">
                        <li class="nav-item active">
                          <a class="nav-link" href="<?php echo e(route('blog')); ?>">BLOG <span class="sr-only">(current)</span></a>
                        </li>
                   
                      </ul>
                       
                        <a style="color:white" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                            <?php echo e(Auth::user()->email); ?> 
                        </a>
                        <ul class="dropdown-menu">
                          <li><a style="color:black" href="<?php echo e(route('logoutaksi')); ?>">
                            <i class="fa fa-power-off"></i> 
                            Log Out
                        </a></li>
                           
                        </ul>
                
                
                    </div>

                  </nav>

                <?php echo $__env->yieldContent('konten'); ?>

            
        </div>
    </body>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
</html><?php /**PATH /opt/lampp/htdocs/sederhana/resources/views/tem.blade.php ENDPATH**/ ?>