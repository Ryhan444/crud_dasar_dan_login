<?php $__env->startSection('konten'); ?>
<br><hr>
    <h4>
        Selamat Datang 
        <b><?php echo e(Auth::user()->name); ?></b>, 
        Anda Login sebagai 
        <b><?php echo e(Auth::user()->email); ?></b>
    </h4>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tem', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/sederhana/resources/views/home.blade.php ENDPATH**/ ?>